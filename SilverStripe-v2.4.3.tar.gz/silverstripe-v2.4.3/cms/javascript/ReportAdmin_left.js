if(typeof SiteTreeHandlers == 'undefined') SiteTreeHandlers = {};

SiteTree.prototype = {
	castAsTreeNode: function(li) {
		behaveAs(li, SiteTreeNode, this.options);
	},
	
	getIdxOf : function(treeNode) {
		if(treeNode && treeNode.id)
			return treeNode.id;
	},
	
	getTreeNodeByIdx : function(idx) {
		if(!idx) idx = "0";
		return document.getElementById(idx);
	},
	
	initialise: function() {
		this.observeMethod('SelectionChanged', this.changeCurrentTo);	
	}

};

SiteTreeNode.prototype.onselect = function() {
	$('sitetree').changeCurrentTo(this);
	if($('sitetree').notify('SelectionChanged', this)) {
		this.getPageFromServer();
	}
	return false; 
};

SiteTreeNode.prototype.getPageFromServer = function() {
	if(this.id)
		$('Form_EditForm').getPageFromServer(this.id);
};

function reloadSiteTree() {
	
	new Ajax.Request( 'admin/report/getsitetree', {
		method: get,
		onSuccess: function( response ) {
			$('sitetree_holder').innerHTML = response.responseText;
		},
		onFailure: function( response ) {
				
		}	
	});

}
